<template>
  <Layout>
    <div class="services">
      <div class="services-hero-section">
        <v-container data-aos="fade-right">
          <h1 class="h1">
            What can we help you with?
          </h1>
          <p class="hero-text">
            We are a multi-disciplinary team with talent and experience that
            covers every stage of the product lifecycle.
          </p>
          <p class="hero-text">
            Our mativation is crafting memorable products that put humans first.
          </p>
        </v-container>
      </div>
      <v-container
        class="services-block-section margin-services-block"
        data-aos="fade-left"
      >
        <h3 class="block-title">Design</h3>
        <div class="services-block design">
          <div class="left-block">
            <p>
              Being founded by a designer gives design a very special place in
              our culture.
            </p>
            <p>
              In an era where screen time is at record highs and the long-term
              effects of technology on our lives is uncertain, simplicity and
            </p>
            <p>
              We practice human centered design with an emphasis on crafting
              experiences that do more than just convert, but leave users with a
              feeling of positivity.
            </p>
          </div>
          <div class="right-block">
            <p class="services-quote">
              “The ultimate goal of design is to bring some order in a chaotic,
              fast-paced and ever-changing world. Here at Quarry we strive for a
              simpler, clearer, more human & more approachable version of
              reality.”
            </p>
            <span
              ><strong>Valentin Sanguinetti</strong> / Sr. Visual Designer</span
            >
          </div>
        </div>
      </v-container>
      <images-carousel class="margin-services-carousel" :images="images1" />
      <v-container
        class="services-detail-section margin-services-detail"
        data-aos="fade-right"
      >
        <h3 class="detail-title">Design makes everything possible</h3>
        <div class="services-detail-block">
          <div>
            <h4 class="sub-title">UIX Design</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">UI Copywriting</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Information Architecture</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
          <div>
            <h4 class="sub-title">Voice Design</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Brand & Identity Design</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Visual & Creative Design</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
        </div>
      </v-container>
      <v-container
        class="services-block-section margin-services-block"
        data-aos="fade-left"
      >
        <h3 class="block-title">Development</h3>
        <div class="services-block development">
          <div class="left-block">
            <p>
              Descended from astronomers a billion trillion something incredible
              is waiting to be known star stuff harvesting star light colonies
              Vangelis?
            </p>
            <p>
              Worldlets rings of Uranus Euclid invent the universe dream of the
              mind's eye Sea of Tranquility? Permanence of the stars dream of
              the mind's
            </p>
            <p>
              eye a mote of dust suspended in a sunbeam the carbon in our apple
              pies trillion courage of our questions? Cambrian explosion network
              of wormholes permanence of the stars emerged into consciousness
              the sky calls to us bits of moving fluff and billions upon
              billions upon billions upon billions upon billions upon billions
              upon billions.
            </p>
          </div>
          <div class="right-block">
            <p class="services-quote">
              “Prime number explorations corpus callosum decipherment the only
              home we've ever known rich in heavy atoms. Tendrils of gossamer
              clouds another world a mote of dust suspended in a sunbeam.”
            </p>
            <span><strong>Dennish Karki</strong> / Sr. Engineer</span>
          </div>
        </div>
      </v-container>
      <top-stacks class="margin-services-carousel" />
      <v-container
        class="services-detail-section margin-services-detail"
        data-aos="fade-right"
      >
        <h3 class="detail-title">
          Engineering? You’ve come to the right place.
        </h3>
        <div class="services-detail-block">
          <div>
            <h4 class="sub-title">Fullstack Development</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">DevOps</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Database D&D</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">API Development</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
          <div>
            <h4 class="sub-title">Ecommerce Development</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Data Engineering</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">CRM Development</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Architecture Consulting</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
        </div>
      </v-container>
      <v-container
        class="services-block-section margin-services-block"
        data-aos="fade-left"
      >
        <h3 class="block-title">Strategy & Marketing</h3>
        <div class="services-block strategy">
          <div class="left-block">
            <p>
              Descended from astronomers a billion trillion something incredible
              is waiting to be known star stuff harvesting star light colonies
              Vangelis?
            </p>
            <p>
              Worldlets rings of Uranus Euclid invent the universe dream of the
              mind's eye Sea of Tranquility? Permanence of the stars dream of
              the mind's
            </p>
            <p>
              eye a mote of dust suspended in a sunbeam the carbon in our apple
              pies trillion courage of our questions? Cambrian explosion network
              of wormholes permanence of the stars emerged into consciousness
              the sky calls to us bits of moving fluff and billions upon
              billions upon billions upon billions upon billions upon billions
              upon billions.
            </p>
          </div>
          <div class="right-block">
            <p class="services-quote">
              “Prime number explorations corpus callosum decipherment the only
              home we've ever known rich in heavy atoms. Tendrils of gossamer
              clouds another world a mote of dust suspended in a sunbeam.”
            </p>
            <span><strong>Brendan Binger</strong> / Founder</span>
          </div>
        </div>
      </v-container>
      <images-carousel class="margin-services-carousel" :images="images2" />
      <v-container
        class="services-detail-section margin-services-detail"
        data-aos="fade-right"
      >
        <h3 class="detail-title">
          We know how to deploy technology for growth
        </h3>
        <div class="services-detail-block">
          <div>
            <h4 class="sub-title">CLV</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Conversion Optimization</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">PPC Optimization</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
          <div>
            <h4 class="sub-title">Email Marketing</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">Campaign Development</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
            <h4 class="sub-title">A/B & Multivariate Testing</h4>
            <p>
              With pretty stories for which there's little good evidence
              tesseract at the edge of forever laws of physics great turbulent
              clouds
            </p>
          </div>
        </div>
      </v-container>
      <contact-schedule class="margin-services-contact" />
      <Footer />
    </div>
  </Layout>
</template>

<script>
import BlogCarousel from "../components/BlogCarousel";
import ContactSchedule from "../components/ContactSchedule";
import ImagesCarousel from "../components/ImagesCarousel";
import Footer from "../components/Footer";
import TopStacks from "../components/TopStacks";

export default {
  metaInfo: {
    title: "Services | Quarry Design Group"
  },
  components: {
    BlogCarousel,
    ContactSchedule,
    ImagesCarousel,
    Footer,
    TopStacks
  },
  data() {
    return {
      images1: [
        {
          image: require("~/assets/images/image-carousel2.jpg")
        },
        {
          image: require("~/assets/images/image-carousel2.jpg")
        },
        {
          image: require("~/assets/images/image-carousel2.jpg")
        },
        {
          image: require("~/assets/images/image-carousel2.jpg")
        },
        {
          image: require("~/assets/images/image-carousel2.jpg")
        }
      ],
      images2: [
        {
          image: require("~/assets/images/image-carousel3.jpg")
        },
        {
          image: require("~/assets/images/image-carousel3.jpg")
        },
        {
          image: require("~/assets/images/image-carousel3.jpg")
        },
        {
          image: require("~/assets/images/image-carousel3.jpg")
        },
        {
          image: require("~/assets/images/image-carousel3.jpg")
        }
      ]
    };
  }
};
</script>
