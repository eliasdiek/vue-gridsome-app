export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Quarry",
  "siteUrl": "",
  "version": "0.7.12"
}