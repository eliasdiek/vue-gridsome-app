export default [
  {
    path: "/cases/:id/",
    component: () => import(/* webpackChunkName: "page--src-templates-word-press-cases-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\templates\\WordPressCases.vue")
  },
  {
    path: "/blog/:id/",
    component: () => import(/* webpackChunkName: "page--src-templates-word-press-post-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\templates\\WordPressPost.vue")
  },
  {
    path: "/team/",
    component: () => import(/* webpackChunkName: "page--src-pages-team-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Team.vue")
  },
  {
    path: "/services/",
    component: () => import(/* webpackChunkName: "page--src-pages-services-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Services.vue")
  },
  {
    path: "/case-detail/",
    component: () => import(/* webpackChunkName: "page--src-pages-case-detail-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\CaseDetail.vue")
  },
  {
    path: "/cases/",
    component: () => import(/* webpackChunkName: "page--src-pages-cases-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Cases.vue")
  },
  {
    path: "/contact/",
    component: () => import(/* webpackChunkName: "page--src-pages-contact-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Contact.vue")
  },
  {
    path: "/blog/",
    component: () => import(/* webpackChunkName: "page--src-pages-blog-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Blog.vue")
  },
  {
    name: "404",
    path: "/404/",
    component: () => import(/* webpackChunkName: "page--node-modules-gridsome-app-pages-404-vue" */ "F:\\workspace\\vue-gridsome-app\\node_modules\\gridsome\\app\\pages\\404.vue")
  },
  {
    name: "home",
    path: "/",
    component: () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "F:\\workspace\\vue-gridsome-app\\src\\pages\\Index.vue")
  },
  {
    name: "*",
    path: "*",
    component: () => import(/* webpackChunkName: "page--node-modules-gridsome-app-pages-404-vue" */ "F:\\workspace\\vue-gridsome-app\\node_modules\\gridsome\\app\\pages\\404.vue")
  }
]

