import plugin_gridsome_plugin_pwa_6 from "F:\\workspace\\vue-gridsome-app\\node_modules\\gridsome-plugin-pwa\\gridsome.client.js"

export default [
  {
    run: plugin_gridsome_plugin_pwa_6,
    options: {"title":"Quarry","serviceWorkerPath":"\\service-worker.js","manifestPath":"\\manifest.json","statusBarStyle":"default","themeColor":"#000000"}
  }
]
