<template>
  <div class="email-cta-wrapper">
    <div class="email-cta-inner-wrapper">
      <div class="email-cta-background"></div>
      <v-container class="email-cta-section">
        <div class="email-cta-content">
          <h3>Get our blogs in your inbox</h3>
          <p>No spam. Ever.</p>
          <p>Only good, clean value. Scout’s honor.</p>
          <v-row class="align-center">
            <div class="email-cta-group">
              <v-text-field
                class="email-cta-input"
                placeholder="Your email"
              ></v-text-field>
              <v-btn depressed>Blog Me</v-btn>
            </div>
          </v-row>
        </div>
      </v-container>
    </div>
  </div>
</template>
