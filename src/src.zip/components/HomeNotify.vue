<template>
  <v-layout justify-center class="quarry-section notify-section">
    <div class="home-notify">
      <div data-aos="fade-right" data-aos-once="true" class="hey">
        Hey there!
      </div>
      <div class="year-dash" data-aos="fade-down" data-aos-once="true">
        <div class="dash"></div>
        <div class="year">Since 2016</div>
      </div>
    </div>
    <v-flex
      data-aos="fade-down"
      data-aos-once="true"
      class="home-notify-content"
    >
      <p>
        We’re a globally distributed web and technology team with talent
        spanning every step of the product lifecycle. We’re dedicated to our
        craft, dedicated to our clients, and dedicated to each other. Passion
        for the work that we do, and the way that we do it is what drives us.
        We’ll work closely with you and your team to design, develop, and ship
        your project better than you thought possible and faster than you
        expected.
      </p>
      <p>Let’s build something awesome.</p>
    </v-flex>
  </v-layout>
</template>
